namespace RpgApi.Models.Enums
{
    public enum ClasseEnum
    {
        Cavaleiro =1,
        Mago =2,
        Clerigo=3
    }
}